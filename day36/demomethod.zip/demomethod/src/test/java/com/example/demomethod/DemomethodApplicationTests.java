package com.example.demomethod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomethodApplicationTests {

	@Test
	void contextLoads() {
	}

}
