package com.example.demomovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomovieApplication.class, args);
	}

}
