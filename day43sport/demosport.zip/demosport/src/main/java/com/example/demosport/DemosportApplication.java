package com.example.demosport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemosportApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemosportApplication.class, args);
	}

}
