package com.example.demosport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosportApplicationTests {

	@Test
	void contextLoads() {
	}

}
