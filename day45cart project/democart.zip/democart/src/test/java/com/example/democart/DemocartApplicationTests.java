package com.example.democart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemocartApplicationTests {

	@Test
	void contextLoads() {
	}

}
